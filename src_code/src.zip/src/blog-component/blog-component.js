import React from 'react';

const Blog = (props)=>{
    return(
        <div>Iam in blog Component</div>
    )
}

export default Blog;