import React from 'react';

const Home = (props )=>{
    return(
        <div>welcome to my Home</div>
    )
}

export default Home;